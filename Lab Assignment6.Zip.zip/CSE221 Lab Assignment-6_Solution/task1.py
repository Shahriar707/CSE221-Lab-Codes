input1Txt = open("task1_input.txt", "r")
output1Txt = open("task1_output.txt", "w")
file = input1Txt.readlines()

data_table = [('Y',"Yasnaya"), ('R',"Rozhok"), ('S',"School"), ('P',"Pochinki"), ('F',"Farm"), ('M',"Mylta"), ('H',"Shelter"), ('I',"Prison")]
total_zones = int(file[0])
zones_predic = file[1]
zones_result = file[2]

lst1 = list(zones_predic)
lst1.pop()
lst2 = list(zones_result)
prediction = ""
result = ""
for i in lst1:
    prediction = prediction + str(i)
for i in lst2:
    result = result + str(i)

def LCS(X, Y, Z, D):
    x = len(X)
    y = len(Y)
    mat = [[0 for i in range(x)] for j in range(y)]
    for i in range(x):
        for j in range(y):
            if X[i-1] == Y[j-1]:
                mat[i][j] = mat[i-1][j-1] + 1
            else:
                mat[i][j] = max(mat[i-1][j], mat[i][j-1])
    lcs_zones = mat[i][j]
    last = mat[i][j]
    i = x
    j = y
    seq = [""] * (last+1)
    seq[last] = ""
    while i>0 and j>0:
        if X[i-1] == Y[j-1]:
            seq[last-1] = X[i-1]
            i = i - 1
            j = j - 1
            last = last - 1
        elif mat[i-1][j] > mat[i][j-1]:
            i = i - 1
        else:
            j = j - 1
    seqeunece = "".join(seq)
    s = list(seqeunece)
    seq2 = []
    for i in range(0, len(s)):
        for j in range(0, len(data_table)):
            if s[i] == data_table[j][0]:
                seq2.append(data_table[j][1])
    seq3 = ""
    for i in range(0, len(seq2)):
        seq3 = seq3 + seq2[i] + " "
    output1Txt.write(str(seq3))
    output1Txt.write("\n")
    correctness = int((lcs_zones * 100) / total_zones)
    output1Txt.write("Correctness of prediction: " + str(correctness) + "%")
LCS(prediction, result, total_zones, data_table)