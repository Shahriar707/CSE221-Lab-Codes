input2Txt = open("task2_input.txt", "r")
output2Txt = open("task2_output.txt", "w")
file = input2Txt.readlines()

first = file[0]
second = file[1]
third = file[2]
lst1 = list(first)
lst2 = list(second)
lst3 = list(third)
A = ""
B = ""
C = ""
for i in lst1:
    A = A + str(i)
for i in lst2:
    B = B + str(i)
for i in lst3:
    C = C + str(i)


def LCS(X, Y, Z):
    x = len(X)
    y = len(Y)
    z = len(Z)
    mat = [[[0 for i in range(x + 1)] for j in range(y + 1)] for k in range(z + 1)]
    for i in range(x + 1):
        for j in range(y + 1):
            for k in range(z + 1):
                if X[i - 1] == Y[j - 1] and Y[j - 1] == Z[k - 1]:
                    mat[i][j][k] = mat[i - 1][j - 1][k - 1] + 1
                else:
                    mat[i][j][k] = max(max(mat[i - 1][j][k], mat[i][j - 1][k]), mat[i][j][k - 1])
    return mat[i][j][k]


length = LCS(A, B, C)
output2Txt.write(str(length))