input3Txt = open("task3_input.txt", "r")
output3Txt = open("task3_output.txt", "w")
file = input3Txt.readlines()
x = tuple(file[0])
y = tuple(file[1])
z = tuple(file[2])
n = int(x[0])
activity = []
for i in y:
    if i.isdigit():
        activity.append(int(i))
childs = []
for i in z:
    childs.append(i)

activity.sort()
Jacks_lst = []
x = 0
result = []

for i in childs:
    if i == "J":
        result.append(activity[x])
        Jacks_lst.append(activity[x])
        x = x + 1
    elif i == "j":
        result.append(Jacks_lst.pop())
result1 = ""
for i in result:
    result1 = result1 + str(i)

jack_workhour = []
jill_workhour = []

for i in range(0, len(childs)):
    if childs[i] == "J":
        jack_workhour.append(result[i])
    else:
        jill_workhour.append(result[i])

sum1 = sum(jack_workhour)
sum2 = sum(jill_workhour)
output3Txt.write(str(result1))
output3Txt.write("\n")
output3Txt.write("Jack will work for " + str(sum1) + " hours")
output3Txt.write("\n")
output3Txt.write("Jill will work for " + str(sum2) + " hours")