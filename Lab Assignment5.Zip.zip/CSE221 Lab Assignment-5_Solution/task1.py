input1Txt = open("input1.txt", "r")
output1Txt = open("output1.txt", "w")
file = input1Txt.readlines()
y = file.pop(0)
x = int(y)
r1 = file.pop(0)
r2 = file.pop(0)
r3 = file.pop(0)
r4 = file.pop(0)
r5 = file.pop(0)
r6 = file.pop(0)
a1 = tuple(r1)
a2 = tuple(r2)
a3 = tuple(r3)
a4 = tuple(r4)
a5 = tuple(r5)
a6 = tuple(r6)
R1 = (int(a1[0]), int(a1[2]))
R2 = (int(a2[0]), int(a2[2]))
R3 = (int(a3[0]), int(a3[2]))
R4 = (int(a4[0]), int(a4[2]))
R5 = (int(a5[0]), int(a5[2]))
R6 = (int(a6[0]), int(a6[2]))
A = [R1, R2, R3, R4, R5, R6]
A.sort(key=lambda x: x[1])

def assignment_selection(A, schedule):
    ending = 0
    for i in A:
        if ending <= i[0]:
            ending = i[1]
            schedule.append(i)
    return schedule

schedule = []
schedule = assignment_selection(A, schedule)

B = len(schedule)
C = schedule

output1Txt.write(str(B))
output1Txt.write("\n")
for i in C:
    output1Txt.write(str(i) + " ")