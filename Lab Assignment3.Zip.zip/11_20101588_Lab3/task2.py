inputTxt = open("input.txt", "r")
outputTxt = open("output2.txt", "w")

file = inputTxt.readlines()
lst1 = []
lst1.append(file[0])
file.pop(0)
A = [int(x) for x in lst1]

dic = dict()
for i in range(0, len(file)):
    m = []
    n = file[i].split()
    for j in range(1, len(n)):
        m.append(n[j])
    dic[n[0]] = m

num_keys = len(dic.keys())
count = 0
for key, value in dic.items():
    if isinstance(value, list):
        count = count + len(value)
num_values = count
keys_list = list(dic.keys())
values_list = list(dic.values())

all_edges = []
for i in dic:
    temp = dic.get(i)
    for j in range(len(temp)):
        all_edges.append((i, temp[j]))

adj_list = dic
class Queue:
    def __init__(self):
        self.items = []

    def is_empty(self):
        return self.items == []

    def enqueue(self, item):
        self.items.insert(0, item)

    def dequeue(self):
        return self.items.pop()

    def size(self):
        return len(self.items)

class Graph:
    def __init__(self, Nodes):
        self.nodes = Nodes
        self.adj_list = {}
        for node in self.nodes:
            self.adj_list[node] = []

    def add_edge(self, u, v):
        self.adj_list[u].append(v)
        self.adj_list[v].append(u)

    def print_adj_list(self):
        print("Adjacency List: ")
        print()
        for node in self.nodes:
            print(node, "-->", self.adj_list[node])

    def BFS(self, graph, source, destination):

        visited = {}
        adjacent = {}
        distance = {}
        bfs_road = []
        queue = Queue()
        for node in adj_list.keys():
            visited[node] = False
            adjacent[node] = None
            distance[node] = -1

        source = "1"
        visited[source] = True
        distance[source] = 0
        queue.enqueue(source)

        while not queue.is_empty():
            u = queue.dequeue()
            if u == destination:
                bfs_road.append(u)
                break
            else:
                bfs_road.append(u)

            for v in adj_list[u]:
                if not visited[v]:
                    visited[v] = True
                    adjacent[v] = u
                    distance[v] = distance[u] + 1
                    queue.enqueue(v)
        Roadmap = [int(x) for x in bfs_road]
        road = ""
        outputTxt.write(str("Places: "))
        for i in Roadmap:
            road = road + str(i) + " "
        outputTxt.write(str(road))


all_edges = []
for i in dic:
    temp = dic.get(i)
    for j in range(len(temp)):
        all_edges.append((i, temp[j]))

nodes = keys_list
graph = Graph(nodes)
for u, v in all_edges:
    graph.add_edge(u, v)
visited = [0] * num_keys
graph.BFS(adj_list, "1", "12")