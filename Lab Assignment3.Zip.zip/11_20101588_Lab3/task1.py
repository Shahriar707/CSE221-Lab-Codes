inputTxt = open("input.txt", "r")
outputTxt = open("output.txt", "w")

file = inputTxt.readlines()
lst1 = []
lst1.append(file[0])
file.pop(0)
A = [int(x) for x in lst1]

dic = dict()
for i in range(0, len(file)):
    m = []
    n = file[i].split()
    for j in range(1, len(n)):
        m.append(n[j])
    dic[n[0]] = m
newdic = dict()
for i in dic:
    newdic[i] = [int(x) for x in dic[i]]

num_keys = len(newdic.keys())
count = 0
for key, value in newdic.items():
    if isinstance(value, list):
        count = count + len(value)
num_values = count

keys = newdic.keys()
keys_list = list(keys)
values = newdic.values()
values_list = list(values)


adj_list = dic
class Graph:
    def __init__(self, Nodes):
        self.nodes = Nodes
        self.adj_list = {}

        for node in self.nodes:
            self.adj_list[node] = []

    #   for adjacency list
    def add_edge(self, u, v):
        self.adj_list[u].append(v)
        self.adj_list[v].append(u)

    def print_adj_list(self):
        print("Adjacency List: ")
        print()
        for node in self.nodes:
            print(node, "-->", self.adj_list[node])

    #   for adjacency matrix
    def adj_matrix(self):
        size = len(keys)
        S = [[0] * size for i in range(size)]
        for a, b in [(keys.index(a), keys.index(b)) for a, row in dic.items() for b in row]:
            S[a][b] = 1

        print("Adjacency Matrix: ")
        print()
        print(S)

all_edges = []
for i in dic:
    temp = dic.get(i)
    for j in range(len(temp)):
        all_edges.append((i, temp[j]))

nodes = keys_list
graph = Graph(nodes)
for u,v in all_edges:
    graph.add_edge(u,v)
graph.print_adj_list()
outputTxt.write(str(graph.print_adj_list()))