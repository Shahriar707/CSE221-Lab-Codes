inputTxt = open("input.txt", "r")
outputTxt = open("output2.txt", "w")

file = inputTxt.readlines()
lst1 = []
lst1.append(file[0])
file.pop(0)
A = [int(x) for x in lst1]

dic = dict()
for i in range(0, len(file)):
    m = []
    n = file[i].split()
    for j in range(1, len(n)):
        m.append(n[j])
    dic[n[0]] = m

num_keys = len(dic.keys())
count = 0
for key, value in dic.items():
    if isinstance(value, list):
        count = count + len(value)
num_values = count
keys_list = list(dic.keys())
values_list = list(dic.values())

all_edges = []
for i in dic:
    temp = dic.get(i)
    for j in range(len(temp)):
        all_edges.append((i, temp[j]))

adj_list = dic
class Graph:
    def __init__(self, Nodes):
        self.nodes = Nodes
        self.adj_list = {}
        for node in self.nodes:
            self.adj_list[node] = []

    def add_edge(self, u, v):
        self.adj_list[u].append(v)

    def print_adj_list(self):
        print("Adjacency List: ")
        print()
        for node in self.nodes:
            print(node, "-->", self.adj_list[node])
    
all_edges = []
for i in dic:
    temp = dic.get(i)
    for j in range(len(temp)):
        all_edges.append((i, temp[j]))

colour = {}
adjacent = {}
time = {}
dfs_road = []

for node in adj_list.keys():
    colour[node] = "W"
    adjacent[node] = None
    time[node] = [-1, -1]

duration = 0
def dfs_util(u, dest):
    global duration
    colour[u] = "G"
    time[u][0] = duration
    if u == dest:
        dfs_road.append(u)
        roadmap = [int(x) for x in dfs_road]
        places = ""
        for i in roadmap:
            places = places + str(i) + " "
        outputTxt.write(str("Places: "))
        outputTxt.write(str(places))
        exit()
    else:
        dfs_road.append(u)
    duration = duration + 1
    for v in adj_list[u]:
        if colour[v] == "W":
            adjacent[v] = u
            dfs_util(v, dest)
    colour[u] = "B"
    time[u][1] = duration
    duration = duration + 1

dest = "12"
for u in adj_list.keys():
    if colour[u] == "W":
        dfs_util(u, dest)

nodes = keys_list
graph = Graph(nodes)
for u, v in all_edges:
    graph.add_edge(u, v)

print(dfs_util("1", "12"))