inputTxt = open("input.txt", "r")
outputTxt = open("output.txt", "w")
recordTxt = open("record.txt", "w")

file = inputTxt.readlines()
digit = []
parity = []
palindrome = []
word = []

for i in file:
    x = i.split(" ")
    digit.append(x[0])
    word.append(x[1])

oPar = 0
ePar = 0
nPar = 0
for i in digit:
    a = float(i)
    if a%1 != 0:
        parity.append("cannot have parity")
        nPar += 1
    else:
        if a%2 == 0:
            parity.append("has even parity")
            ePar += 1
        else:
            parity.append("has odd parity")
            oPar += 1

yPal = 0
nPal = 0
for j in word:
    m = 0
    n = len(j)-1
    if n == 0:
        palindrome.append("empty word")
    else:
        for k in range(0, int(n/2)):
            if j[k] != j[n-1-k]:
                m = m + 1
        if m != 0:
            palindrome.append("is not a palindrome")
            nPal += 1
        else:
            palindrome.append("is a palindrome")
            yPal += 1


for i in range(len(palindrome)):
    outputTxt.write(digit[i] + " " + parity[i] + " " + "and" + " " + word[i] + " " + palindrome[i] + "\n")

oParP = (int(oPar)/5)*100
eParP = (int(ePar)/5)*100
nParP = (int(nPar)/5)*100
yPalP = (int(yPal)/5)*100
nPalP = (int(nPal)/5)*100
recordTxt.write("Percentage of odd parity: " + str(oParP) + "%\n")
recordTxt.write("Percentage of even parity: " + str(eParP) + "%\n")
recordTxt.write("Percentage of no parity: " + str(nParP) + "%\n")
recordTxt.write("Percentage of palindrome: " + str(yPalP) + "%\n")
recordTxt.write("Percentage od non-palindrome: " + str(nPalP) + "%\n")