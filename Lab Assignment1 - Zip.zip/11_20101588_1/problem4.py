inputTxt = open("input4.txt", "r")
outputTxt = open("output4.txt", "w")

file = inputTxt.readlines()

A = []
B = []
M = A
for i in file:
    if "," not in i:
        M = B
    else:
        M.append([])
        for j in i.split(","):
            N = len(M)
            M[N-1].append(int(j))

C = [[0,0,0],
     [0,0,0],
     [0,0,0]]


for i in range(0, len(A)):
    for j in range(0, len(B[0])):
        for k in range(0, len(B)):
            C[i][j] += A[i][k] * B[k][j]

for i in C:
    outputTxt.write(str(i)+"\n")