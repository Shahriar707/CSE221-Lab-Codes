input2Txt = open("input2.txt", "r")
output2Txt = open("output2.txt", "w")

file = input2Txt.readlines()
file.pop(0)
file.pop(1)
file.pop(2)
array1 = []
array2 = []
array3 = []
array1.append(file[0])
array2.append(file[1])
for i in range(2, len(file)):
    array3.append(file[i])

array1new = []
array2new = []
array3new = []

for i in array1:
    for j in i:
        array1new.append(j)
array1new.append(0)
array1new.pop(1)
array1new.pop(2)
for i in array2:
    for j in i:
        array2new.append(j)
array2new.pop(1)
array2new.pop(2)
array2new.pop(2)
array2new.pop(2)
array2new.pop(2)
array2new.append(10)
for i in array3:
    for j in i:
        array3new.append(j)

array3_1 = []
for i in range(0, len(array3new), 2):
    array3_1.append(array3new[i])

graph1 = {}
data_11 = {array1new[0]: {array1new[1]: array1new[2]}}
data_12 = {array1new[1]: {array1new[0]: array1new[2]}}
graph1.update(data_11)
graph1.update(data_12)

graph2 = {}
data_21 = {array2new[0]: {array2new[1]: array2new[2]}}
data_22 = {array2new[1]: {array2new[0]: array2new[2]}}
graph2.update(data_22)
graph2.update(data_21)

graph3 = {}
data_31 = {array3_1[3]: {array3_1[4]: int(array3_1[5]), array3_1[10]: int(array3_1[11])}}
data_32 = {array3_1[6]: {array3_1[7]: int(array3_1[8]), array3_1[16]: int(array3_1[17])}}
data_33 = {array3_1[0]: {array3_1[1]: int(array3_1[2])}}
data_34 = {array3_1[12]: {array3_1[13]: int(array3_1[14])}}
data_35 = {array3_1[1]: {array3_1[0]: int(array3_1[2])}}
graph3.update(data_31)
graph3.update(data_32)
graph3.update(data_33)
graph3.update(data_34)
graph3.update(data_35)


def Dijkstra(graph, start, goal):
    shortest_distance = {}
    track_predecessor = {}
    unseenNodes = graph
    infinity = 100000000
    track_record = []

    for node in unseenNodes:
        shortest_distance[node] = infinity
    shortest_distance[start] = 0

    while unseenNodes:
        min_distance_node = None

        for node in unseenNodes:
            if min_distance_node is None:
                min_distance_node = node
            elif shortest_distance[node] < shortest_distance[min_distance_node]:
                min_distance_node = node

        path_options = graph[min_distance_node].items()

        for child_node, weight in path_options:
            if weight + shortest_distance[min_distance_node] < shortest_distance[child_node]:
                shortest_distance[child_node] = weight + shortest_distance[min_distance_node]
                track_predecessor[child_node] = min_distance_node

        unseenNodes.pop(min_distance_node)

    currentNode = goal

    while currentNode != start:
        try:
            track_record.insert(0, currentNode)
            currentNode = track_predecessor[currentNode]
        except KeyError:
            output1Txt.write("Path is not reachable")
            break
    track_record.insert(0, start)

    if shortest_distance[goal] != infinity:
        roadmap = " "
        for i in track_record:
            if i == '0':
                break
            else:
                roadmap = roadmap + i + " "
        output2Txt.write(str(roadmap))
        output2Txt.write(str("\n"))


Dijkstra(graph1, '1', '0')
Dijkstra(graph2, '1', '2')
Dijkstra(graph3, '1', '5')