from queue import PriorityQueue

input4Txt = open("input4.txt", "r")
output4Txt = open("output4.txt", "w")

file = input4Txt.readlines()
max_value = 9999999
new1 = []
for i in file:
    new1.append(i.strip())
element = []
for i in new1:
    for j in i:
        element.append(j)
element.pop(2)
element.pop(5)
element.pop(7)
element.pop(8)
element.pop(11)
element.pop(13)
element.pop(14)
element.pop(17)
element.pop(19)
element.pop(20)
element.pop(22)
element.pop(23)
element.pop(25)
element.pop(26)
element.pop(28)
element.pop(29)
element.pop(31)
element.pop(32)
lst = [int(x) for x in element]


class Store:
    def __init__(self, a, b):
        self.d = a
        self.v = b


class Node:
    def __init__(self, a, b, c):
        self.u = a
        self.v = b
        self.w = c


graph = []
y = lst.pop(0)
while y > 0:
    n = lst.pop(0)
    m = lst.pop(0)

    for i in range(n - 1):
        graph[i] = []

    for i in range(m):
        u = lst.pop(0)
        v = lst.pop(0)
        w = lst.pop(0)

        cost = Node(u, v, w)
        graph[u].append(cost)
        s = lst.pop(0)
        vis = []
        res = []
        Dijkstra(graph, vis, res, s, n)
        for i in range(n + 1):
            if i == s:
                res[i] = 0
            output4Txt.write(res[i] + " ")
        output4Txt.write("\n")


def Dijkstra(graph, vis, dis, s, n):
    ps = PriorityQueue()

    for i in range(n - 1):
        dis[i] = -1

    ps.put(Store(max_value, s))
    dis[s] = max_value

    while not ps.empty():
        current = ps.get()

        for node in graph:
            if min(dis[current.v], i.w) > dis[i.v]:
                dis[i.v] = min(current.v), i.w
                ps.put(Store(dis[i.v], i.v))